The binary versions of the FFmpeg libraries in this ZIP archive originate from
[pyglet-ffmpeg](https://github.com/pythonarcade/pyglet-ffmpeg), which contains
th following notice:
    We believe an intact redistribution of binaries is permitted. But this
    ultimately is your responsibility to verify.

For FFmpeg lincensing information see LICENSE.md (included in this ZIP archive).
